<?php
function sc_front__header_entry(){
    do_action('sc_front_header_entry');
}
function sc_bred_crumbs(){
    do_action('sc_bred_crumbs');
}
function sc_before_content(){
    do_action('sc_before_content');
}
function sc_after_content(){
    do_action('sc_after_content');
}
?>
